#!/bin/bash
# 在 Linux 服务器上：把游戏资源注入一个现成的未签名 ipa，重新打包
# 用法: ./inject_www_into_ipa.sh 空壳.ipa /data/web 输出.ipa
set -e
IPA="$1"; SRC="${2:-/data/web}"; OUT="${3:-YDXZ-full-unsigned.ipa}"
[ -f "$IPA" ] || { echo "找不到 ipa: $IPA"; exit 1; }

WORK=$(mktemp -d)
unzip -q "$IPA" -d "$WORK"
APP=$(ls -d "$WORK"/Payload/*.app 2>/dev/null | head -1)
[ -d "$APP" ] || { echo "ipa 结构不对，缺 Payload/*.app"; exit 1; }
echo ">> 目标 app: $APP"

echo ">> 复制资源（排除重复 assets/、ht、gz、备份）"
rm -rf "$APP/www"
mkdir -p "$APP/www"
if command -v rsync >/dev/null; then
  rsync -a --exclude 'assets' --exclude 'ht' --exclude '@ws-packet' \
        --exclude '*.gz' --exclude '*.bak*' --exclude 'dl' "$SRC"/ "$APP/www"/
else
  cp -a "$SRC"/. "$APP/www"/
  rm -rf "$APP/www/assets" "$APP/www/ht" "$APP/www/@ws-packet" "$APP/www/dl"
  find "$APP/www" -name '*.gz' -delete
fi

echo ">> 修补 index.html"
python3 - "$APP/www/index.html" "http://YOUR_SERVER" <<'PY'
import sys
p, srv = sys.argv[1], sys.argv[2]
s = open(p, encoding='utf-8').read()
s = s.replace('window.VOUCHER_API = window.location.origin + "/ht/api/voucher.php";',
              'window.VOUCHER_API = "%s/ht/api/voucher.php";' % srv)
open(p,'w',encoding='utf-8').write(s)
print('   ok')
PY

echo ">> 去掉旧签名"
rm -rf "$APP/_CodeSignature" "$APP/embedded.mobileprovision"

echo ">> 重新打包"
cd "$WORK"
zip -qry -0 "$OUT" Payload
mv "$OUT" "$OLDPWD/" 2>/dev/null || true
cd "$OLDPWD"
rm -rf "$WORK"

echo "✅ $OUT  $(du -h "$OUT" | cut -f1)"
echo "   ⚠️ 注入后签名已失效，必须重新签名再安装"
