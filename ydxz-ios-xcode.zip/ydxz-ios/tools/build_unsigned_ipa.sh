#!/bin/bash
# 编译并产出未签名 IPA（在 macOS 上运行）
set -e
cd "$(dirname "$0")/.."

if [ ! -f YDXZ/www/index.html ]; then
  echo "!! 还没放游戏资源。先执行："
  echo "   tools/copy_resources.sh /path/to/web"
  echo " 仍要继续（只打包空壳，运行时走线上地址）？按 Ctrl+C 取消，5 秒后继续"
  sleep 5
fi

echo ">> 清理"
rm -rf build Payload YDXZ-unsigned.ipa

echo ">> 编译（关闭签名）"
xcodebuild \
  -project YDXZ.xcodeproj \
  -target YDXZ \
  -configuration Release \
  -sdk iphoneos \
  CODE_SIGN_IDENTITY="" \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGNING_ALLOWED=NO \
  CONFIGURATION_BUILD_DIR="$PWD/build" \
  build

APP="build/YDXZ.app"
[ -d "$APP" ] || { echo "!! 编译产物不存在：$APP"; exit 1; }

echo ">> 去掉已有签名残留"
rm -rf "$APP/_CodeSignature" "$APP/embedded.mobileprovision"

echo ">> 组装 Payload"
mkdir -p Payload
cp -R "$APP" Payload/

echo ">> 打包 ipa（结构必须是 Payload/YDXZ.app/**）"
zip -qry -0 YDXZ-unsigned.ipa Payload
unzip -l YDXZ-unsigned.ipa | head -5

echo ""
echo "✅ 完成：$(pwd)/YDXZ-unsigned.ipa  ($(du -h YDXZ-unsigned.ipa | cut -f1))"
echo "   这是未签名包，用 Sideloadly / AltStore / 爱思助手 / 企业证书工具自签后安装。"
