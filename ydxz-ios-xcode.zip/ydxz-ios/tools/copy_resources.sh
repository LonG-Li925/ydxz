#!/bin/bash
# 把游戏网页资源复制进 Xcode 工程的 YDXZ/www 目录，并打好补丁
# 用法:
#   ./copy_resources.sh /path/to/web            # 从本机已有目录复制
#   ./copy_resources.sh --download              # 从线上服务器拉（需要 curl + 能访问 8081）
set -e
cd "$(dirname "$0")/.."
DEST="YDXZ/www"
SRV="http://36.134.112.211:8081"

if [ "$1" = "--download" ]; then
  echo ">> 从 $SRV 下载资源清单（这一步只是提示，正式发布请用服务器上的 /data/web 目录）"
  echo "!! 直接下载整站不可行（约 2.1G，且分目录），建议在服务器上打包后传本机"
  exit 1
fi

SRC="${1:-/data/web}"
[ -d "$SRC" ] || { echo "源目录不存在: $SRC"; exit 1; }

echo ">> 清理旧资源"
rm -rf "$DEST"
mkdir -p "$DEST"

echo ">> 复制（排除重复的 assets/、ht 后台、备份、gz 预压缩）"
rsync -a --delete \
  --exclude 'assets' \
  --exclude 'ht' \
  --exclude '@ws-packet' \
  --exclude '*.gz' \
  --exclude '*.bak*' \
  --exclude 'dbg_task.js' \
  --exclude 'dl' \
  "$SRC"/ "$DEST"/

echo ">> 修补 index.html（file:// 下 location.origin 无效，必须写死绝对地址）"
python3 - "$DEST/index.html" "$SRV" <<'PY'
import sys, re
p, srv = sys.argv[1], sys.argv[2]
s = open(p, encoding='utf-8').read()
s = s.replace('window.VOUCHER_API = window.location.origin + "/ht/api/voucher.php";',
              'window.VOUCHER_API = "%s/ht/api/voucher.php";' % srv)
s = s.replace('window.location.origin', '"%s"' % srv)
open(p, 'w', encoding='utf-8').write(s)
print('   VOUCHER_API ->', srv)
PY

echo ">> 完成，体积：$(du -sh "$DEST" | cut -f1)"
echo "   文件数：$(find "$DEST" -type f | wc -l)"
