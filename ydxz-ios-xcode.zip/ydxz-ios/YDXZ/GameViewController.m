#import "GameViewController.h"
#import <WebKit/WebKit.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <errno.h>
#include <string.h>

static const uint16_t kLocalPort = 18765;

static NSString *YDXZInfoString(NSString *key)
{
    id v = [[NSBundle mainBundle] objectForInfoDictionaryKey:key];
    return ([v isKindOfClass:[NSString class]] && [(NSString *)v length] > 0) ? (NSString *)v : nil;
}

static NSString *YDXZRemoteURL(void)  { return YDXZInfoString(@"RemoteBaseURL"); }
static NSString *YDXZConfigBase(void) { return YDXZInfoString(@"ConfigProxyBase"); }
static NSString *YDXZWebBase(void)    { return YDXZInfoString(@"WebProxyBase"); }

static const char *YDXZMimeType(NSString *ext)
{
    static NSDictionary *map = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        map = @{
            @"html": @"text/html; charset=utf-8",
            @"htm":  @"text/html; charset=utf-8",
            @"js":   @"application/javascript; charset=utf-8",
            @"css":  @"text/css; charset=utf-8",
            @"json": @"application/json; charset=utf-8",
            @"txt":  @"text/plain; charset=utf-8",
            @"xml":  @"application/xml; charset=utf-8",
            @"fnt":  @"text/plain; charset=utf-8",
            @"atlas":@"text/plain; charset=utf-8",
            @"png":  @"image/png",
            @"jpg":  @"image/jpeg",
            @"jpeg": @"image/jpeg",
            @"gif":  @"image/gif",
            @"webp": @"image/webp",
            @"svg":  @"image/svg+xml",
            @"ico":  @"image/x-icon",
            @"mp3":  @"audio/mpeg",
            @"ogg":  @"audio/ogg",
            @"wav":  @"audio/wav",
            @"mp4":  @"video/mp4",
            @"ktx":  @"image/ktx",
            @"pvr":  @"image/pvr",
            @"woff": @"font/woff",
            @"woff2":@"font/woff2",
            @"ttf":  @"font/ttf",
            @"otf":  @"font/otf",
        };
    });
    NSString *v = map[ext.lowercaseString];
    return v ? v.UTF8String : "application/octet-stream";
}

#pragma mark - 上游反向代理（页面同源请求 -> 原生转发，彻底避开跨域）

static NSData *YDXZProxyFetch(NSString *base, NSString *method, NSString *path,
                              NSDictionary *headers, NSData *body,
                              NSInteger *statusOut, NSString **ctypeOut)
{
    NSString *urlStr = [base stringByAppendingString:path];
    NSURL *url = [NSURL URLWithString:urlStr];
    if (!url) return nil;

    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    req.HTTPMethod = method;
    req.timeoutInterval = 20.0;
    if (body.length) req.HTTPBody = body;

    NSArray *skip = @[@"host", @"content-length", @"connection", @"origin",
                      @"referer", @"accept-encoding", @"accept-language", @"user-agent"];
    for (NSString *k in headers) {
        if ([skip containsObject:k.lowercaseString]) continue;
        [req setValue:headers[k] forHTTPHeaderField:k];
    }

    dispatch_semaphore_t sem = dispatch_semaphore_create(0);
    __block NSData *outData = nil;
    __block NSInteger st = 502;
    __block NSString *ct = @"application/json";

    NSURLSessionDataTask *task = [[NSURLSession sharedSession]
        dataTaskWithRequest:req
          completionHandler:^(NSData *d, NSURLResponse *r, NSError *e) {
              if (e) NSLog(@"[YDXZ] proxy %@ %@ error: %@", method, path, e.localizedDescription);
              outData = d ?: [NSData data];
              if ([r isKindOfClass:[NSHTTPURLResponse class]]) {
                  NSHTTPURLResponse *hr = (NSHTTPURLResponse *)r;
                  st = hr.statusCode;
                  for (NSString *hk in hr.allHeaderFields) {
                      if ([hk.lowercaseString isEqualToString:@"content-type"]) {
                          ct = hr.allHeaderFields[hk];
                          break;
                      }
                  }
              }
              dispatch_semaphore_signal(sem);
          }];
    [task resume];
    dispatch_semaphore_wait(sem, dispatch_time(DISPATCH_TIME_NOW, 25 * NSEC_PER_SEC));

    *statusOut = st;
    if (ctypeOut) *ctypeOut = ct;
    NSLog(@"[YDXZ] proxy %@ %@ -> %ld (%lu bytes)", method, path, (long)st, (unsigned long)outData.length);
    return outData;
}

#pragma mark - 本地 HTTP 服务（仅回环）

@interface YDXZLocalServer : NSObject
@property (nonatomic, assign) int listenFD;
@property (nonatomic, assign) uint16_t port;
@property (nonatomic, strong) NSString *root;
@property (nonatomic, assign) BOOL running;
- (BOOL)startWithRoot:(NSString *)root port:(uint16_t)port;
- (void)stop;
@end

@interface YDXZLocalServer ()
- (void)acceptLoop;
- (void)handleClient:(int)client;
@end

@implementation YDXZLocalServer

- (BOOL)startWithRoot:(NSString *)root port:(uint16_t)port
{
    self.root = root;
    self.listenFD = -1;
    self.port = 0;

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return NO;

    int on = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &on, sizeof(on));

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    addr.sin_port = htons(port);

    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        addr.sin_port = 0;
        if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
            close(fd);
            return NO;
        }
    }
    if (listen(fd, 256) < 0) {
        close(fd);
        return NO;
    }

    socklen_t len = sizeof(addr);
    getsockname(fd, (struct sockaddr *)&addr, &len);
    self.port = ntohs(addr.sin_port);
    self.listenFD = fd;
    self.running = YES;

    NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(acceptLoop) object:nil];
    thread.name = @"YDXZLocalServer";
    thread.stackSize = 512 * 1024;
    [thread start];

    NSLog(@"[YDXZ] local server on 127.0.0.1:%u root=%@", self.port, self.root);
    return YES;
}

- (void)acceptLoop
{
    while (self.running) {
        int client = accept(self.listenFD, NULL, NULL);
        if (client < 0) {
            if (errno == EINTR) continue;
            break;
        }
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [self handleClient:client];
        });
    }
}

- (void)stop
{
    self.running = NO;
    if (self.listenFD >= 0) {
        shutdown(self.listenFD, SHUT_RDWR);
        close(self.listenFD);
        self.listenFD = -1;
    }
}

static BOOL YDXZSendAll(int fd, const void *buf, size_t len)
{
    const char *p = (const char *)buf;
    size_t left = len;
    while (left > 0) {
        ssize_t n = send(fd, p, left, 0);
        if (n <= 0) {
            if (n < 0 && errno == EINTR) continue;
            return NO;
        }
        p += n;
        left -= (size_t)n;
    }
    return YES;
}

- (void)handleClient:(int)client
{
    struct timeval tv = { 20, 0 };
    setsockopt(client, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(client, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    int on = 1;
    setsockopt(client, IPPROTO_TCP, TCP_NODELAY, &on, sizeof(on));

    NSMutableData *buf = [NSMutableData data];
    char tmp[8192];
    NSUInteger headLen = 0;
    NSUInteger bodyLen = 0;

    while (buf.length < 16 * 1024 * 1024) {
        ssize_t n = recv(client, tmp, sizeof(tmp), 0);
        if (n <= 0) break;
        [buf appendBytes:tmp length:(NSUInteger)n];

        NSData *sep = [@"\r\n\r\n" dataUsingEncoding:NSASCIIStringEncoding];
        NSRange hr = [buf rangeOfData:sep options:0 range:NSMakeRange(0, buf.length)];
        if (hr.location == NSNotFound) continue;
        headLen = hr.location + hr.length;

        NSString *h = [[NSString alloc] initWithBytes:buf.bytes
                                               length:headLen
                                             encoding:NSISOLatin1StringEncoding];
        if (!h) break;
        for (NSString *line in [h componentsSeparatedByString:@"\r\n"]) {
            NSString *low = line.lowercaseString;
            if ([low hasPrefix:@"content-length:"]) {
                NSString *v = [[line substringFromIndex:15]
                    stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
                bodyLen = (NSUInteger)[v longLongValue];
                break;
            }
        }
        if (buf.length >= headLen + bodyLen) break;
    }

    if (headLen == 0) {
        close(client);
        return;
    }

    NSString *head = [[NSString alloc] initWithBytes:buf.bytes
                                              length:headLen
                                            encoding:NSISOLatin1StringEncoding];
    if (!head) {
        close(client);
        return;
    }

    NSArray *lines = [head componentsSeparatedByString:@"\r\n"];
    NSString *requestLine = lines.count > 0 ? lines[0] : @"";
    NSArray *parts = [requestLine componentsSeparatedByString:@" "];
    NSString *method = parts.count > 0 ? parts[0] : @"GET";
    NSString *target = parts.count > 1 ? parts[1] : @"/";

    NSMutableDictionary *reqHeaders = [NSMutableDictionary dictionary];
    for (NSUInteger i = 1; i < lines.count; i++) {
        NSString *line = lines[i];
        NSRange colon = [line rangeOfString:@":"];
        if (colon.location == NSNotFound) continue;
        NSString *k = [line substringToIndex:colon.location];
        NSString *v = [[line substringFromIndex:colon.location + 1]
            stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        if (k.length) reqHeaders[k] = v;
    }

    NSData *reqBody = [NSData data];
    if (bodyLen > 0 && buf.length > headLen) {
        NSUInteger n = MIN(bodyLen, buf.length - headLen);
        reqBody = [buf subdataWithRange:NSMakeRange(headLen, n)];
    }

    // 预检
    if ([method isEqualToString:@"OPTIONS"]) {
        const char *resp = "HTTP/1.1 204 No Content\r\n"
                           "Access-Control-Allow-Origin: *\r\n"
                           "Access-Control-Allow-Methods: GET, HEAD, POST, OPTIONS\r\n"
                           "Access-Control-Allow-Headers: *\r\n"
                           "Access-Control-Max-Age: 86400\r\n"
                           "Content-Length: 0\r\n"
                           "Connection: close\r\n\r\n";
        YDXZSendAll(client, resp, strlen(resp));
        close(client);
        return;
    }

    // 解析 Range
    long long rangeStart = -1, rangeEnd = -1;
    for (NSString *line in lines) {
        if ([line.lowercaseString hasPrefix:@"range:"]) {
            NSString *v = [[line substringFromIndex:6] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            if ([v hasPrefix:@"bytes="]) {
                v = [v substringFromIndex:6];
                NSArray *se = [v componentsSeparatedByString:@"-"];
                if (se.count == 2) {
                    rangeStart = [[se objectAtIndex:0] longLongValue];
                    NSString *e = [se objectAtIndex:1];
                    rangeEnd = e.length ? [e longLongValue] : -1;
                }
            }
            break;
        }
    }

    NSString *path = target;
    NSRange q = [path rangeOfString:@"?"];
    if (q.location != NSNotFound) path = [path substringToIndex:q.location];
    path = [path stringByRemovingPercentEncoding] ?: path;
    if (path.length == 0 || [path isEqualToString:@"/"]) path = @"/index.html";

    NSString *full = [self.root stringByAppendingPathComponent:path];
    NSString *std = [[full stringByStandardizingPath] copy];
    NSString *rootStd = [self.root stringByStandardizingPath];
    BOOL ok = [std hasPrefix:rootStd];

    BOOL isDir = NO;
    if (ok && [[NSFileManager defaultManager] fileExistsAtPath:std isDirectory:&isDir] && isDir) {
        std = [std stringByAppendingPathComponent:@"index.html"];
    }
    BOOL exists = ok && [[NSFileManager defaultManager] fileExistsAtPath:std];

    // 找不到的接口请求：由原生转发到上游（页面同源，无跨域）
    if (!exists) {
        NSString *ext = path.pathExtension.lowercaseString;
        BOOL looksLikeApi = ([path hasSuffix:@".do"] || [path hasPrefix:@"/ht/"] ||
                             [path hasPrefix:@"/sys/"] || ext.length == 0 ||
                             [ext isEqualToString:@"php"] || [ext isEqualToString:@"json"]);
        NSString *base = [path hasPrefix:@"/ht/"] ? YDXZWebBase() : YDXZConfigBase();
        if (looksLikeApi && base) {
            NSInteger st = 502;
            NSString *ct = @"application/json";
            NSData *out = YDXZProxyFetch(base, method, path, reqHeaders, reqBody, &st, &ct);
            if (out) {
                char hdr[512];
                snprintf(hdr, sizeof(hdr),
                         "HTTP/1.1 %ld %s\r\n"
                         "Content-Type: %s\r\n"
                         "Content-Length: %lu\r\n"
                         "Access-Control-Allow-Origin: *\r\n"
                         "Cache-Control: no-store\r\n"
                         "Connection: close\r\n\r\n",
                         (long)st, (st == 200 ? "OK" : (st == 404 ? "Not Found" : "Bad Gateway")),
                         ct.UTF8String, (unsigned long)out.length);
                YDXZSendAll(client, hdr, strlen(hdr));
                if (![method isEqualToString:@"HEAD"] && out.length) {
                    YDXZSendAll(client, out.bytes, out.length);
                }
                close(client);
                return;
            }
        }

        const char *body = "404 Not Found";
        char resp[512];
        snprintf(resp, sizeof(resp),
                 "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain; charset=utf-8\r\n"
                 "Content-Length: %zu\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n%s",
                 strlen(body), body);
        YDXZSendAll(client, resp, strlen(resp));
        close(client);
        return;
    }

    int ffd = open(std.fileSystemRepresentation, O_RDONLY);
    if (ffd < 0) {
        close(client);
        return;
    }
    struct stat st;
    if (fstat(ffd, &st) != 0) {
        close(ffd);
        close(client);
        return;
    }
    long long size = (long long)st.st_size;

    long long sendStart = 0, sendLen = size;
    BOOL partial = NO;
    if (rangeStart >= 0 && size > 0) {
        sendStart = rangeStart;
        if (sendStart >= size) sendStart = 0;
        long long last = (rangeEnd >= 0 && rangeEnd < size) ? rangeEnd : (size - 1);
        sendLen = last - sendStart + 1;
        if (sendLen <= 0) sendLen = size - sendStart;
        partial = YES;
    }

    NSString *ext = std.pathExtension ?: @"";
    const char *mime = YDXZMimeType(ext);
    BOOL noCache = [@[@"html", @"htm", @"js", @"css", @"json"] containsObject:ext.lowercaseString];

    char header[1024];
    if (partial) {
        snprintf(header, sizeof(header),
                 "HTTP/1.1 206 Partial Content\r\n"
                 "Content-Type: %s\r\n"
                 "Content-Length: %lld\r\n"
                 "Content-Range: bytes %lld-%lld/%lld\r\n"
                 "Accept-Ranges: bytes\r\n"
                 "Access-Control-Allow-Origin: *\r\n"
                 "Cache-Control: %s\r\n"
                 "Connection: close\r\n\r\n",
                 mime, sendLen, sendStart, sendStart + sendLen - 1, size,
                 noCache ? "no-cache" : "public, max-age=86400");
    } else {
        snprintf(header, sizeof(header),
                 "HTTP/1.1 200 OK\r\n"
                 "Content-Type: %s\r\n"
                 "Content-Length: %lld\r\n"
                 "Accept-Ranges: bytes\r\n"
                 "Access-Control-Allow-Origin: *\r\n"
                 "Cache-Control: %s\r\n"
                 "Connection: close\r\n\r\n",
                 mime, size, noCache ? "no-cache" : "public, max-age=86400");
    }

    if (!YDXZSendAll(client, header, strlen(header))) {
        close(ffd);
        close(client);
        return;
    }

    if (![method isEqualToString:@"HEAD"]) {
        off_t offset = (off_t)sendStart;
        off_t remain = (off_t)sendLen;
        char *chunkBuf = (char *)malloc(262144);
        if (chunkBuf) {
            while (remain > 0) {
                size_t want = (size_t)MIN((off_t)262144, remain);
                ssize_t rd = pread(ffd, chunkBuf, want, offset);
                if (rd <= 0) break;
                if (!YDXZSendAll(client, chunkBuf, (size_t)rd)) break;
                offset += rd;
                remain -= rd;
            }
            free(chunkBuf);
        }
    }

    close(ffd);
    close(client);
}

@end

#pragma mark - 游戏容器

@interface GameViewController () <WKNavigationDelegate, WKUIDelegate>
@property (nonatomic, strong) WKWebView *webView;
@property (nonatomic, strong) YDXZLocalServer *server;
@end

@implementation GameViewController

- (BOOL)prefersStatusBarHidden { return YES; }
- (BOOL)prefersHomeIndicatorAutoHidden { return YES; }
- (BOOL)shouldAutorotate { return NO; }
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];

    WKWebViewConfiguration *cfg = [[WKWebViewConfiguration alloc] init];
    cfg.allowsInlineMediaPlayback = YES;
    if (@available(iOS 10.0, *)) {
        cfg.mediaTypesRequiringUserActionForPlayback = WKAudiovisualMediaTypeNone;
    }
    cfg.allowsAirPlayForMediaPlayback = NO;

    NSString *js = @"var m=document.createElement('meta');m.name='viewport';"
                   @"m.content='width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no';"
                   @"document.getElementsByTagName('head')[0].appendChild(m);"
                   @"document.addEventListener('touchmove',function(e){e.preventDefault();},{passive:false});";
    WKUserScript *us = [[WKUserScript alloc] initWithSource:js
                                             injectionTime:WKUserScriptInjectionTimeAtDocumentEnd
                                          forMainFrameOnly:YES];
    [cfg.userContentController addUserScript:us];

    self.webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:cfg];
    self.webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.webView.navigationDelegate = self;
    self.webView.UIDelegate = self;
    self.webView.opaque = NO;
    self.webView.backgroundColor = [UIColor blackColor];
    self.webView.scrollView.scrollEnabled = NO;
    self.webView.scrollView.bounces = NO;
    self.webView.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    if (@available(iOS 16.4, *)) { self.webView.inspectable = NO; }

    [self.view addSubview:self.webView];
    [self loadGame];
}

- (void)loadGame {
    NSString *bundle = [[NSBundle mainBundle] bundlePath];
    NSString *www = [bundle stringByAppendingPathComponent:@"www"];
    NSString *idx = [www stringByAppendingPathComponent:@"index.html"];

    if (![[NSFileManager defaultManager] fileExistsAtPath:idx]) {
        NSString *remote = YDXZRemoteURL();
        if (remote) {
            NSLog(@"[YDXZ] no local www, loading remote %@", remote);
            [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:remote]]];
        } else {
            NSLog(@"[YDXZ] no local www and no RemoteBaseURL configured");
        }
        return;
    }

    self.server = [[YDXZLocalServer alloc] init];
    if ([self.server startWithRoot:www port:kLocalPort]) {
        NSString *url = [NSString stringWithFormat:@"http://127.0.0.1:%u/index.html", self.server.port];
        NSLog(@"[YDXZ] loading local via %@", url);
        [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]];
    } else {
        NSLog(@"[YDXZ] local server failed, fallback file://");
        NSURL *dirURL = [NSURL fileURLWithPath:www isDirectory:YES];
        NSURL *idxURL = [NSURL fileURLWithPath:idx];
        [self.webView loadFileURL:idxURL allowingReadAccessToURL:dirURL];
    }
}

#pragma mark - WKUIDelegate

- (void)webView:(WKWebView *)webView
runJavaScriptAlertPanelWithMessage:(NSString *)message
initiatedByFrame:(WKFrameInfo *)frame
completionHandler:(void (^)(void))completionHandler {
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:nil
                                                              message:message
                                                       preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:ac animated:YES completion:nil];
    completionHandler();
}

- (void)webView:(WKWebView *)webView
runJavaScriptConfirmPanelWithMessage:(NSString *)message
initiatedByFrame:(WKFrameInfo *)frame
completionHandler:(void (^)(BOOL))completionHandler {
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:nil
                                                              message:message
                                                       preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *a) { completionHandler(NO); }]];
    [ac addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { completionHandler(YES); }]];
    [self presentViewController:ac animated:YES completion:nil];
}

#pragma mark - WKNavigationDelegate

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    NSLog(@"[YDXZ] navigation failed: %@", error);
    NSString *host = webView.URL.host;
    BOOL local = [host isEqualToString:@"127.0.0.1"];
    NSString *remote = YDXZRemoteURL();
    if (local && remote) {
        [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:remote]]];
    }
}

- (void)dealloc {
    [self.server stop];
}

@end
