#import "GameViewController.h"
#import <WebKit/WebKit.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <errno.h>
#include <string.h>

static NSString * const kRemoteURL = @"http://36.134.112.211:8081/";
static const uint16_t kLocalPort = 18765;

static const char *YDXZMimeType(NSString *ext)
{
    static NSDictionary *map = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        map = @{
            @"html": @"text/html; charset=utf-8",
            @"htm":  @"text/html; charset=utf-8",
            @"js":   @"application/javascript; charset=utf-8",
            @"css":  @"text/css; charset=utf-8",
            @"json": @"application/json; charset=utf-8",
            @"txt":  @"text/plain; charset=utf-8",
            @"xml":  @"application/xml; charset=utf-8",
            @"fnt":  @"text/plain; charset=utf-8",
            @"atlas":@"text/plain; charset=utf-8",
            @"png":  @"image/png",
            @"jpg":  @"image/jpeg",
            @"jpeg": @"image/jpeg",
            @"gif":  @"image/gif",
            @"webp": @"image/webp",
            @"svg":  @"image/svg+xml",
            @"ico":  @"image/x-icon",
            @"mp3":  @"audio/mpeg",
            @"ogg":  @"audio/ogg",
            @"wav":  @"audio/wav",
            @"mp4":  @"video/mp4",
            @"ktx":  @"image/ktx",
            @"pvr":  @"image/pvr",
            @"woff": @"font/woff",
            @"woff2":@"font/woff2",
            @"ttf":  @"font/ttf",
            @"otf":  @"font/otf",
        };
    });
    NSString *v = map[ext.lowercaseString];
    return v ? v.UTF8String : "application/octet-stream";
}

#pragma mark - 本地 HTTP 服务（仅回环，把 bundle/www 以 http 提供）

@interface YDXZLocalServer : NSObject
@property (nonatomic, assign) int listenFD;
@property (nonatomic, assign) uint16_t port;
@property (nonatomic, strong) NSString *root;
@property (nonatomic, assign) BOOL running;
- (BOOL)startWithRoot:(NSString *)root port:(uint16_t)port;
- (void)stop;
@end

@interface YDXZLocalServer ()
- (void)acceptLoop;
- (void)handleClient:(int)client;
@end

@implementation YDXZLocalServer

- (BOOL)startWithRoot:(NSString *)root port:(uint16_t)port
{
    self.root = root;
    self.listenFD = -1;
    self.port = 0;

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return NO;

    int on = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &on, sizeof(on));

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    addr.sin_port = htons(port);

    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        // 端口被占用，让系统随机分配
        addr.sin_port = 0;
        if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
            close(fd);
            return NO;
        }
    }
    if (listen(fd, 256) < 0) {
        close(fd);
        return NO;
    }

    socklen_t len = sizeof(addr);
    getsockname(fd, (struct sockaddr *)&addr, &len);
    self.port = ntohs(addr.sin_port);
    self.listenFD = fd;
    self.running = YES;

    NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(acceptLoop) object:nil];
    thread.name = @"YDXZLocalServer";
    thread.stackSize = 512 * 1024;
    [thread start];

    NSLog(@"[YDXZ] local server on 127.0.0.1:%u root=%@", self.port, self.root);
    return YES;
}

- (void)acceptLoop
{
    while (self.running) {
        int client = accept(self.listenFD, NULL, NULL);
        if (client < 0) {
            if (errno == EINTR) continue;
            break;
        }
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [self handleClient:client];
        });
    }
}

- (void)stop
{
    self.running = NO;
    if (self.listenFD >= 0) {
        shutdown(self.listenFD, SHUT_RDWR);
        close(self.listenFD);
        self.listenFD = -1;
    }
}

static BOOL YDXZSendAll(int fd, const void *buf, size_t len)
{
    const char *p = (const char *)buf;
    size_t left = len;
    while (left > 0) {
        ssize_t n = send(fd, p, left, 0);
        if (n <= 0) {
            if (n < 0 && errno == EINTR) continue;
            return NO;
        }
        p += n;
        left -= (size_t)n;
    }
    return YES;
}

- (void)handleClient:(int)client
{
    struct timeval tv = { 15, 0 };
    setsockopt(client, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(client, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    int on = 1;
    setsockopt(client, IPPROTO_TCP, TCP_NODELAY, &on, sizeof(on));

    NSMutableData *buf = [NSMutableData data];
    char tmp[8192];

    while (buf.length < 65536) {
        ssize_t n = recv(client, tmp, sizeof(tmp), 0);
        if (n <= 0) break;
        [buf appendBytes:tmp length:(NSUInteger)n];
        NSString *s = [[NSString alloc] initWithData:buf encoding:NSUTF8StringEncoding];
        if (s && [s rangeOfString:@"\r\n\r\n"].location != NSNotFound) break;
    }

    NSString *head = [[NSString alloc] initWithData:buf encoding:NSUTF8StringEncoding];
    if (!head) head = [[NSString alloc] initWithData:buf encoding:NSISOLatin1StringEncoding];
    if (head.length == 0) {
        close(client);
        return;
    }

    NSArray *lines = [head componentsSeparatedByString:@"\r\n"];
    NSString *requestLine = lines.count > 0 ? lines[0] : @"";
    NSArray *parts = [requestLine componentsSeparatedByString:@" "];
    NSString *method = parts.count > 0 ? parts[0] : @"GET";
    NSString *target = parts.count > 1 ? parts[1] : @"/";

    // 预检请求
    if ([method isEqualToString:@"OPTIONS"]) {
        const char *resp = "HTTP/1.1 204 No Content\r\n"
                           "Access-Control-Allow-Origin: *\r\n"
                           "Access-Control-Allow-Methods: GET, HEAD, OPTIONS\r\n"
                           "Access-Control-Allow-Headers: *\r\n"
                           "Access-Control-Max-Age: 86400\r\n"
                           "Content-Length: 0\r\n"
                           "Connection: close\r\n\r\n";
        YDXZSendAll(client, resp, strlen(resp));
        close(client);
        return;
    }

    // 解析 Range
    long long rangeStart = -1, rangeEnd = -1;
    for (NSString *line in lines) {
        if ([line.lowercaseString hasPrefix:@"range:"]) {
            NSString *v = [[line substringFromIndex:6] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            if ([v hasPrefix:@"bytes="]) {
                v = [v substringFromIndex:6];
                NSArray *se = [v componentsSeparatedByString:@"-"];
                if (se.count == 2) {
                    rangeStart = [[se objectAtIndex:0] longLongValue];
                    NSString *e = [se objectAtIndex:1];
                    rangeEnd = e.length ? [e longLongValue] : -1;
                }
            }
            break;
        }
    }

    // 路径处理
    NSString *path = target;
    NSRange q = [path rangeOfString:@"?"];
    if (q.location != NSNotFound) path = [path substringToIndex:q.location];
    path = [path stringByRemovingPercentEncoding] ?: path;
    if (path.length == 0 || [path isEqualToString:@"/"]) path = @"/index.html";

    NSString *full = [self.root stringByAppendingPathComponent:path];
    NSString *std = [[full stringByStandardizingPath] copy];
    NSString *rootStd = [self.root stringByStandardizingPath];
    BOOL ok = [std hasPrefix:rootStd];

    BOOL isDir = NO;
    if (ok && [[NSFileManager defaultManager] fileExistsAtPath:std isDirectory:&isDir] && isDir) {
        std = [std stringByAppendingPathComponent:@"index.html"];
    }

    if (!ok || ![[NSFileManager defaultManager] fileExistsAtPath:std]) {
        const char *body = "404 Not Found";
        char resp[512];
        snprintf(resp, sizeof(resp),
                 "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain; charset=utf-8\r\n"
                 "Content-Length: %zu\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n%s",
                 strlen(body), body);
        YDXZSendAll(client, resp, strlen(resp));
        close(client);
        return;
    }

    int ffd = open(std.fileSystemRepresentation, O_RDONLY);
    if (ffd < 0) {
        close(client);
        return;
    }
    struct stat st;
    if (fstat(ffd, &st) != 0) {
        close(ffd);
        close(client);
        return;
    }
    long long size = (long long)st.st_size;

    long long sendStart = 0, sendLen = size;
    BOOL partial = NO;
    if (rangeStart >= 0 && size > 0) {
        sendStart = rangeStart;
        if (sendStart >= size) sendStart = 0;
        long long last = (rangeEnd >= 0 && rangeEnd < size) ? rangeEnd : (size - 1);
        sendLen = last - sendStart + 1;
        if (sendLen <= 0) sendLen = size - sendStart;
        partial = YES;
    }

    NSString *ext = std.pathExtension ?: @"";
    const char *mime = YDXZMimeType(ext);
    BOOL noCache = [@[@"html", @"htm", @"js", @"css", @"json"] containsObject:ext.lowercaseString];

    char header[1024];
    if (partial) {
        snprintf(header, sizeof(header),
                 "HTTP/1.1 206 Partial Content\r\n"
                 "Content-Type: %s\r\n"
                 "Content-Length: %lld\r\n"
                 "Content-Range: bytes %lld-%lld/%lld\r\n"
                 "Accept-Ranges: bytes\r\n"
                 "Access-Control-Allow-Origin: *\r\n"
                 "Cache-Control: %s\r\n"
                 "Connection: close\r\n\r\n",
                 mime, sendLen, sendStart, sendStart + sendLen - 1, size,
                 noCache ? "no-cache" : "public, max-age=86400");
    } else {
        snprintf(header, sizeof(header),
                 "HTTP/1.1 200 OK\r\n"
                 "Content-Type: %s\r\n"
                 "Content-Length: %lld\r\n"
                 "Accept-Ranges: bytes\r\n"
                 "Access-Control-Allow-Origin: *\r\n"
                 "Cache-Control: %s\r\n"
                 "Connection: close\r\n\r\n",
                 mime, size, noCache ? "no-cache" : "public, max-age=86400");
    }

    if (!YDXZSendAll(client, header, strlen(header))) {
        close(ffd);
        close(client);
        return;
    }

    if (![method isEqualToString:@"HEAD"]) {
        off_t offset = (off_t)sendStart;
        off_t remain = (off_t)sendLen;
        char *chunkBuf = (char *)malloc(262144);
        if (chunkBuf) {
            while (remain > 0) {
                size_t want = (size_t)MIN((off_t)262144, remain);
                ssize_t rd = pread(ffd, chunkBuf, want, offset);
                if (rd <= 0) break;
                if (!YDXZSendAll(client, chunkBuf, (size_t)rd)) break;
                offset += rd;
                remain -= rd;
            }
            free(chunkBuf);
        }
    }

    close(ffd);
    close(client);
}

@end

#pragma mark - 游戏容器

@interface GameViewController () <WKNavigationDelegate, WKUIDelegate>
@property (nonatomic, strong) WKWebView *webView;
@property (nonatomic, strong) YDXZLocalServer *server;
@end

@implementation GameViewController

- (BOOL)prefersStatusBarHidden { return YES; }
- (BOOL)prefersHomeIndicatorAutoHidden { return YES; }
- (BOOL)shouldAutorotate { return NO; }
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];

    WKWebViewConfiguration *cfg = [[WKWebViewConfiguration alloc] init];
    cfg.allowsInlineMediaPlayback = YES;
    if (@available(iOS 10.0, *)) {
        cfg.mediaTypesRequiringUserActionForPlayback = WKAudiovisualMediaTypeNone;
    }
    cfg.allowsAirPlayForMediaPlayback = NO;

    NSString *js = @"var m=document.createElement('meta');m.name='viewport';"
                   @"m.content='width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no';"
                   @"document.getElementsByTagName('head')[0].appendChild(m);"
                   @"document.addEventListener('touchmove',function(e){e.preventDefault();},{passive:false});";
    WKUserScript *us = [[WKUserScript alloc] initWithSource:js
                                             injectionTime:WKUserScriptInjectionTimeAtDocumentEnd
                                          forMainFrameOnly:YES];
    [cfg.userContentController addUserScript:us];

    self.webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:cfg];
    self.webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.webView.navigationDelegate = self;
    self.webView.UIDelegate = self;
    self.webView.opaque = NO;
    self.webView.backgroundColor = [UIColor blackColor];
    self.webView.scrollView.scrollEnabled = NO;
    self.webView.scrollView.bounces = NO;
    self.webView.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    if (@available(iOS 16.4, *)) { self.webView.inspectable = NO; }

    [self.view addSubview:self.webView];
    [self loadGame];
}

- (void)loadGame {
    NSString *bundle = [[NSBundle mainBundle] bundlePath];
    NSString *www = [bundle stringByAppendingPathComponent:@"www"];
    NSString *idx = [www stringByAppendingPathComponent:@"index.html"];

    if (![[NSFileManager defaultManager] fileExistsAtPath:idx]) {
        NSLog(@"[YDXZ] no local www, loading remote %@", kRemoteURL);
        [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:kRemoteURL]]];
        return;
    }

    // 用回环 HTTP 服务提供本地资源：页面拥有真实 origin，
    // 才能正常跨域请求配置接口、建立 WebSocket、使用本地存储。
    self.server = [[YDXZLocalServer alloc] init];
    if ([self.server startWithRoot:www port:kLocalPort]) {
        NSString *url = [NSString stringWithFormat:@"http://127.0.0.1:%u/index.html", self.server.port];
        NSLog(@"[YDXZ] loading local via %@", url);
        [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]];
    } else {
        NSLog(@"[YDXZ] local server failed, fallback file://");
        NSURL *dirURL = [NSURL fileURLWithPath:www isDirectory:YES];
        NSURL *idxURL = [NSURL fileURLWithPath:idx];
        [self.webView loadFileURL:idxURL allowingReadAccessToURL:dirURL];
    }
}

#pragma mark - WKUIDelegate

- (void)webView:(WKWebView *)webView
runJavaScriptAlertPanelWithMessage:(NSString *)message
initiatedByFrame:(WKFrameInfo *)frame
completionHandler:(void (^)(void))completionHandler {
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:nil
                                                              message:message
                                                       preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:ac animated:YES completion:nil];
    completionHandler();
}

- (void)webView:(WKWebView *)webView
runJavaScriptConfirmPanelWithMessage:(NSString *)message
initiatedByFrame:(WKFrameInfo *)frame
completionHandler:(void (^)(BOOL))completionHandler {
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:nil
                                                              message:message
                                                       preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *a) { completionHandler(NO); }]];
    [ac addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { completionHandler(YES); }]];
    [self presentViewController:ac animated:YES completion:nil];
}

#pragma mark - WKNavigationDelegate

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    NSLog(@"[YDXZ] navigation failed: %@", error);
    NSString *host = webView.URL.host;
    BOOL local = [host isEqualToString:@"127.0.0.1"];
    if (local) {
        // 本地服务异常时退回线上地址，保证能玩
        [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:kRemoteURL]]];
    }
}

- (void)dealloc {
    [self.server stop];
}

@end
