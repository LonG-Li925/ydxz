# 跃动小子 iOS 端（未签名 IPA 工程）

这是一个 **WebView 原生壳**，把《跃动小子》的网页游戏包进 iOS App。
编译产物为 **未签名 IPA**，你可以自己（或找代签）签名后安装到 iPhone / iPad。

- 包名：`com.xingchen.ydxz`
- 显示名：跃动小子
- 系统要求：iOS 13.0+
- 方向：横屏锁定
- 资源策略：优先读 App 内置的 `www/index.html`；没有内置资源时自动回退到线上 `http://36.134.112.211:8081/`

---

## 一、最快的路径（三选一）

### 方案 A：自己有 Mac（5 分钟）

```bash
# 1) 把游戏资源放进工程（约 2.1G，从服务器 /data/web 拷到本机后指定路径）
cd ydxz-ios
./tools/copy_resources.sh /path/to/web

# 2) 一键编译 + 打未签名 ipa
./tools/build_unsigned_ipa.sh
# 产出：ydxz-ios/YDXZ-unsigned.ipa
```

也可以用 Xcode 打开 `YDXZ.xcodeproj` → 选中真机 → Product > Archive → Organizer 里右键 `Show in Finder`，
把 `Products/Applications/YDXZ.app` 拖进 `Payload/` 目录后 `zip` 即可（同样得到未签名 ipa）。

### 方案 B：没有 Mac，用 GitHub 云编译（免费，推荐）

GitHub 提供免费的 macOS 云机器（`macos-14`），**不需要买 Mac**。全程只在网页上点：

1. 新建仓库：github.com → 右上 `+` → New repository → 名字随意（如 `ydxz-ios`）→ **Public**（Public 仓库 Actions 免费不限时）→ Create
2. **上传工程包**：仓库页 → `Add file` → `Upload files` → 把 `ydxz-ios-xcode.zip` 拖进去 → `Commit changes`
3. **建工作流文件**：仓库页 → `Add file` → `Create new file` → 文件名输入
   `.github/workflows/build.yml`（斜杠会自动建目录）→ 把下面内容整段粘贴 → `Commit changes`

   ```yaml
   name: Build IPA
   on: [push, workflow_dispatch]
   jobs:
     build:
       runs-on: macos-14
       steps:
         - uses: actions/checkout@v4
         - run: |
             unzip -q ydxz-ios-xcode.zip -d .
             cd ydxz-ios
             xcodebuild -project YDXZ.xcodeproj -target YDXZ -configuration Release -sdk iphoneos \
               CODE_SIGN_IDENTITY="" CODE_SIGNING_REQUIRED=NO CODE_SIGNING_ALLOWED=NO \
               CONFIGURATION_BUILD_DIR="$PWD/build" build
             mkdir -p Payload && cp -R build/YDXZ.app Payload/
             rm -rf Payload/YDXZ.app/_CodeSignature
             zip -qry -0 YDXZ-unsigned.ipa Payload
             ls -lh YDXZ-unsigned.ipa
         - uses: actions/upload-artifact@v4
           with:
             name: ipa
             path: ydxz-ios/YDXZ-unsigned.ipa
   ```

4. 提交后自动开始编译（若没自动跑：`Actions` 标签 → 左侧 `Build IPA` → 右侧 `Run workflow`）
5. 约 3~5 分钟后，点进那次运行，页面底部 **Artifacts** → 下载 `ipa.zip` → 解压得到 `YDXZ-unsigned.ipa`

> 这是**空壳包（约 1~2 MB，不含 2.1G 游戏资源）**，App 运行时会走线上地址。
> 想要"资源全内置"的完整包，把这个空壳 ipa 发我，我在服务器上注入 2.1G 资源后输出完整未签名 ipa（`tools/inject_www_into_ipa.sh`，几分钟）。
>
> 注意：**不要**把 `YDXZ/www/` 里的 2.1G 资源上传到 GitHub（单文件 100MB 上限、仓库建议 2GB 内）。

> 空壳包因为不含资源，运行时会走线上地址（需要玩家有网且服务器带宽够）。
> 想要"资源全内置"的完整包，把空壳 ipa 发给我，我在服务器上把 2.1G 资源注入并重新打包（`tools/inject_www_into_ipa.sh`，几分钟）。

上传时注意：**不要**把 `YDXZ/www/` 里的 2.1G 资源一起上传（GitHub 单文件上限 100MB、仓库建议 2GB 以内）。工程里 `www/` 只保留空目录即可。

### 方案 C：找代打包 / 代签名（最省事）

淘宝、闲鱼搜「iOS 代打包」「iOS 企业签名」，把本工程压缩包发过去，说明：

- 要 **未签名 ipa** 或 **企业签名 ipa**
- 包名 `com.xingchen.ydxz`
- 资源目录 `YDXZ/www`（他们会帮你放进去编译）

市价：代打包 30~80 元，企业签名 100~300 元/年（越狱/超级签另算）。

---

## 二、资源怎么放

游戏资源在服务器的 `/data/web`（约 4.6G，其中 `assets/` 与 `resource/assets/` 是完全重复的两份）。

`tools/copy_resources.sh` 会自动：

- 排除重复的 `assets/`（省 2.2G）
- 排除 `ht/`（后台）、`@ws-packet`、`*.gz` 预压缩副本、备份文件
- 修补 `index.html`：把 `window.location.origin` 换成绝对地址

> 必须修补的原因：App 内用 `file://` 加载页面，`location.origin` 是 `file://`，
> 代金券接口会拼成 `file:///ht/api/voucher.php` 直接失效。

修补后目录约 **2.1G / 2.5 万个文件**。

---

## 三、签名与安装

未签名 ipa **不能直接安装**，必须签名。可选方式：

| 方式 | 成本 | 有效期 | 说明 |
|---|---|---|---|
| **Sideloadly / AltStore 自签** | 免费 | 7 天（需重签） | 用普通 Apple ID，电脑上操作，最多 3 个 App |
| **Xcode 直接运行** | 免费 | 7 天 | 需要 Mac |
| **Apple 开发者账号** | $99/年 | 1 年 | 可 TestFlight 分发，最正规 |
| **企业签名（第三方）** | 100~300 元/年 | 视服务商 | 会被苹果封证书，需换签 |
| **超级签 / TF 签** | 按设备收费 | 较长 | 稳定性看服务商 |

自签工具：
- Windows：**Sideloadly**、**爱思助手**（工具箱 → IPA 签名）、**AltStore**
- macOS：**AltStore**、Xcode
- 命令行：`ldid -S` / `codesign`（仅越狱或已信任证书场景）

---

## 四、工程结构

```
ydxz-ios/
├── YDXZ.xcodeproj/project.pbxproj   Xcode 工程（Objective-C，无 Storyboard）
├── YDXZ/
│   ├── main.m                       UIApplicationMain 入口
│   ├── AppDelegate.h/.m             创建窗口、锁定横屏
│   ├── GameViewController.h/.m      WKWebView 全屏加载游戏
│   ├── Info.plist                   包名/图标/横屏/ATS 等
│   ├── Assets.xcassets/             14 张应用图标（20~1024）
│   └── www/                         游戏资源放这里（默认空）
├── tools/
│   ├── copy_resources.sh            从 /data/web 复制资源 + 打补丁
│   ├── build_unsigned_ipa.sh        macOS 上一键编译出未签名 ipa
│   └── inject_www_into_ipa.sh       Linux 上把资源注入现成 ipa（服务器用）
└── .github/workflows/
    └── build-unsigned-ipa.yml       GitHub Actions 云编译（无需 Mac）
```

---

## 五、常见问题

**Q：装上去闪退 / 白屏？**
- 白屏先看是否走本地资源：如果 `www/index.html` 缺失会回退线上，需要网络可达。
- 闪退多半是签名不匹配（证书和 Bundle ID 不符），重新签名即可。

**Q：游戏里没有声音？**
- iOS 要求用户交互后才能播放音频，点一下屏幕即可。壳里已设置 `mediaTypesRequiringUserActionForPlayback = None`。

**Q：想改包名？**
- 改 `YDXZ/Info.plist` 的 `CFBundleIdentifier`，同时改 pbxproj 里 `PRODUCT_BUNDLE_IDENTIFIER`。

**Q：想换成竖屏？**
- 改 `Info.plist` 的 `UISupportedInterfaceOrientations` 为 Portrait，
  并改 `AppDelegate.m` 的 `supportedInterfaceOrientationsForWindow` 返回 `UIInterfaceOrientationMaskPortrait`。

**Q：2.1G 会不会太大装不上？**
- iOS 对 ipa 没有安卓那种 2G 解析限制，但安装需要足够空间（约 4~5G）。
- 想瘦身：贴图有 `png`（985M）和 `astc/.ktx`（941M）两套，只留一套可省近 1G，
  但要先确认游戏运行时读的是哪一套（`resource/default.res_*.bin` 里的路径）。
